package com.amitraj.themoviedbapp.listner;

import android.view.View;

/**
 * Created by AmitRaj on 16-Sep-17.
 */

public interface ButtonClickListener {

  void onDevelopedByClickListner();


}
