package com.amitraj.themoviedbapp.listner;

/**
 * Created by AmitRaj on 12-Sep-17.
 */

public interface OnListItemClickListner {
  void onItemClick(int positon);
}
